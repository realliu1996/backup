---
title: about
date: 2017-12-21 17:53:14
type: "about"
---

<font size=4>
姓名：realliu
年龄：弱冠 
所在地：江西            
爱做的事：晒着太阳喝早茶
</font>
<center>
<font size=3 face="YouYuan">
经常用到的搜索网站：
百度：[www.baidu.com](https://www.baidu.com/ "百度") 
谷歌：[www.google.com](https://www.google.com/ "谷歌")
</font>
</center>
<font size=3 face="黑体">
经常用到的下载网站： 
mygithub：[github.com/realliu1996](https://github.com/realliu1996 "github") 
阿里巴巴图标库：[www.iconfont.cn](http://www.iconfont.cn/plus/home/index?spm=a313x.7781069.1998910419.2.FPsshc "iconfont") 
Gallery on ReddPics：[reddpics.com](https://reddpics.com/ "reddpics")
</font>
![](https://i.imgur.com/HahTbgY.jpg) 