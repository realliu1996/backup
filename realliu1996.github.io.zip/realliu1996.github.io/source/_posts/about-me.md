---
title: about me
date: 2017-12-20 14:41:10
categories: "about"
tags:
- about

---



>### who am I ?
>> I can tell you i am realliu 

<!-- more -->



>#### where are me ?
>> I can tell you i am Chian




>##### what are my doing ?
>> I can tell you i am sharing something to you




- my hobby
    >book


- my music
    >sunshine


- my movie
    >no precent



这是一个普通段落：

    这是一个代码区块






This is [百度](https://www.baidu.com/ "baidu") inline link.


This is [百度][id] reference-style link.
[id]: https://www.baidu.com/ "baidu"

I get 10 times more traffic from [Google] [1] than from
[Yahoo] [2] or [MSN] [3].

  [1]: http://google.com/        "Google"
  [2]: http://search.yahoo.com/  "Yahoo Search"
  [3]: http://search.msn.com/    "MSN Search"




*helloworld*

**helloworld**





![Alt text](http://www.taopic.com/uploads/allimg/140421/318743-140421213T910.jpg "富士山")

![](https://i.imgur.com/g4twcr5.png "富士山")



